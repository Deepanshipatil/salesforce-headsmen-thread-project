# 🚀 HeadsMen Thread Project – Salesforce Internship

🔗 **Demo Video**: [Watch on YouTube](https://youtu.be/u54WHcOuPBc?si=_INIXLB5g3BfsHr3)

## 📘 Project Overview
The HeadsMen Thread Project is a Salesforce automation system built during my internship. It helps monitor and manage product stock levels efficiently using Apex Batchable and Schedulable interfaces.

## 🛠️ Technologies Used
- Salesforce Platform
- Apex Classes
- Batch Apex
- Scheduled Apex
- SOQL
- Custom Object: `Product__c`

## 👩‍💻 My Role
- Designed and implemented automation logic
- Created Batch Apex and Scheduler classes
- Tested bulk-safe, governor limit-friendly code
- Documented and demoed the full project

## ✨ Key Features
- Batch Apex class for low-stock product detection
- Apex Scheduler to run jobs daily
- SOQL optimized for large datasets
- Custom logic to update stock status

## 📸 Demo Video
[![Watch on YouTube](https://img.youtube.com/vi/u54WHcOuPBc/0.jpg)](https://youtu.be/u54WHcOuPBc?si=_INIXLB5g3BfsHr3)

## 📝 How to Run
1. Deploy Apex classes
2. Use Anonymous Apex to run or schedule job
```apex
InventoryBatchJob job = new InventoryBatchJob();
Database.executeBatch(job, 200);
InventoryBatchScheduler.scheduleBatchJob();
```

## 📬 Contact
**Deepanshi Patil**  
Salesforce Developer Intern  
📧 Email: your-email@example.com
